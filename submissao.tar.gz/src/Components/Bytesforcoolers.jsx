import { useState } from "react"
import { FaLockOpen } from "react-icons/fa";
import { FaLock } from "react-icons/fa";
import { FaCopy } from "react-icons/fa6";

export function Bytesforcoolers() {


    const corAleatoria = () => {

        const cor = '#' + Math.floor(Math.random() * 16777215).toString(16)

        return cor
    }

    const array = ['', '', '', '', '']

    const arrayCorAleatorio = array.map((e) => corAleatoria())

    const [state, setState] = useState(arrayCorAleatorio)

    const handleclick = (array) => {

        setState(array.map((e, index) => {
            if (lock[index]) {
                return state[index]
            }
            else {
                return corAleatoria()
            }
        }))
    }

    const clickNaDiv = (i) => {
        console.log(state[i])
    }

    const arrayLock = [false, false, false, false, false]

    const [lock, setLock] = useState(arrayLock)

    const handleLockClick = (i) => {

        setLock(previousLock => (previousLock.map((e, index) => {
            if (index === i) {
                return !e;
            } else {
                return e;
            }
        })))

    }


    const copyToClipboard = async (text) => {
        try {
            await navigator.clipboard.writeText(text);
            alert(`Text copied to clipboard: ${text}`, text);
        } catch (error) {
            alert('Error copying to clipboard:', error);
        }
    };

    return (

        <div className="bg-white font-bold pb-px-1 m-5 h-screen">
            <h1 className="text-3xl h-16 pb-px-1">Gerador de Cores</h1>

            <div className="flex justify-center">
                {array.map((cell, i) => (
                    <li className="list-none">
                        <div
                            key={i}
                            style={{ backgroundColor: state[i] }} className="flex items-end justify-center w-60 font-bold m-1 rounded-md h-96"
                            onClick={() => clickNaDiv(i)}
                        >
                            <div className="bg-white rounded-md color text-black m-4 pb-px-1 opacity-75 flex flex-col items-center justify-around w-20 h-28">
                                <h1>{state[i]}</h1>
                                <button onClick={() => handleLockClick(i)}>{lock[i] ? <FaLock /> : <FaLockOpen />}</button>
                                <button onClick={() => copyToClipboard(state[i])}><FaCopy /></button>
                            </div>
                        </div>
                    </li>
                ))}
            </div>
                <button className='p-4 px-7 text-white border-solid m-2 border-indigo-600 border-2 rounded-md bg-indigo-400' onClick={() => handleclick(array)}>Gerar Cor</button>
        </div>
    )





}